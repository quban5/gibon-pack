


#define WATER_PROG
#define WAVY_STRENGTH 1.0 //[0.1 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0]
#define WAVY_SPEED 0.0025 //[0.001 0.01 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 1.0 1.25 1.5 2.0 3.0 4.0]

varying vec4 color;
varying float iswater;
varying vec4 lmtexcoord;
varying vec3 torch;
varying vec3 viewVector;
varying vec3 normal0;
varying vec3 normal1;

attribute vec4 at_tangent;
attribute vec4 mc_Entity;




#include "/lib/sky_function.glsl"


//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

const vec3 torchColor = vec3(3.000, 1.382, 0.408);

void main()
{

    lmtexcoord.xy = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    iswater = 0.0;
    if (dhMaterialId == 12)
        iswater = 1.0;
    viewVector = (gl_ModelViewMatrix * gl_Vertex).xyz;
    color = gl_Color;

    normal0 = gl_NormalMatrix * gl_Normal;
    normal1 = gl_Normal;

    lmtexcoord.zw = (gl_MultiTexCoord1.xy);
    torch = (pow(gl_MultiTexCoord1.x * recip, 3) * 0.5) * mix(torchColor, vec3(1.0), 0.5);
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
}
